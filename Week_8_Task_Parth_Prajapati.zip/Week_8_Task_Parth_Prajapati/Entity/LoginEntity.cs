﻿namespace Entity
{
    public class LoginEntity
    {
        public string EmailId { get; set; }
        public string Password { get; set; }
        public string Role { get; set; }
        //public string JsonString { get; set; }    
    }
}
