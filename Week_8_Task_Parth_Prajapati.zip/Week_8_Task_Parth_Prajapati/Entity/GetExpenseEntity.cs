﻿namespace Entity
{
    public class GetExpenseEntity
    {
        public string ExpenseEmail { get; set; }
    }
}
